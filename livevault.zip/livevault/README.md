# LiveVault — Starter

Starter separado para:
- Frontend React + Vite
- Worker de gravação Python
- FFmpeg
- Redis como fila de tarefas

O backend (`backend/`, FastAPI + SQLite + Redis) implementa o contrato em `docs/BACKEND_CONTRACT.md`.

## Pré-requisitos
- Docker Desktop com Docker Compose
- Para executar o worker fora do Docker: Python 3.11+ e FFmpeg no PATH

## Executar
Na pasta deste projeto:

```powershell
docker compose up --build -d
docker compose ps
```

Aplicação (front + back): http://localhost:8000  
Docs da API: http://localhost:8000/docs  

Para acompanhar o worker:
```powershell
docker compose logs -f recorder
```

Para parar:
```powershell
docker compose down
```

Os vídeos ficam no volume Docker `recordings_data`, montado em `/recordings` dentro do worker. Para produção, implementar upload dos segmentos para MinIO no worker ou em um serviço de armazenamento separado.

## Backend
Configuração opcional: copie `backend/.env.example` para `backend/.env`.

- **API**: dashboard, canais, gravações (listar, parar, baixar, iniciar manualmente), clipes com aprovação, atividade, login.
- **Monitor** (thread interna): consulta Twitch/YouTube/Kick a cada `POLL_INTERVAL_SECONDS` usando as APIs oficiais (precisa das credenciais no `.env`).
- **Eventos**: consome `recordings:events` com fila confiável (`BLMOVE`), retentativas e DLQ `recordings:events:dlq`; ao terminar, une os segmentos em `final.mp4` e gera miniatura.
- **Captura**: o back end só enfileira job quando recebe uma URL temporária autorizada (`MEDIA_PROVIDER_URL`) ou via `POST /api/recordings`. Ele não extrai streams das plataformas.
- **Auth**: `AUTH_ENABLED=false` por padrão porque o front ainda não tem login. Para ligar: `AUTH_ENABLED=true`, `JWT_SECRET` (32+ caracteres) e `ADMIN_PASSWORD`.
- Rode **um único** processo do back end (monitor e consumidor são threads internas). O worker de gravação processa um job por vez; para gravar lives simultâneas escale o `recorder`.

Teste rápido de uma gravação manual (URL de mídia HTTPS de host permitido em `ALLOWED_MEDIA_HOSTS`):
```powershell
curl -X POST localhost:8000/api/channels -H "Content-Type: application/json" -d '{"platform":"twitch","username":"meucanal"}'
curl -X POST localhost:8000/api/recordings -H "Content-Type: application/json" -d '{"channel_id":"<id>","media_url":"https://..."}'
curl -X POST localhost:8000/api/recordings/<id>/stop
```

## Modo de demonstração
Se a API não estiver disponível, o frontend mostra dados demonstrativos e um aviso de modo demonstração. Os botões de ações reais dependem dos endpoints do backend.

## Segurança e plataformas
O worker só aceita URLs HTTPS cujo host esteja na lista `ALLOWED_MEDIA_HOSTS`. Configure os hosts CDN oficiais/permitidos conforme a integração validada de cada plataforma. Não coloque tokens OAuth ou segredos no frontend. URLs assinadas de mídia são temporárias e devem ser entregues pelo backend ao worker, nunca exibidas na interface.

A disponibilidade de captura depende das APIs, permissões e termos de cada plataforma. Detectar uma live não significa que a plataforma forneça automaticamente uma URL de mídia capturável.

## Importante
Este starter não implementa OAuth, monitoramento de canais, extração de streams ou publicação social. Isso pertence ao backend/adaptadores de plataforma e deve respeitar as regras e permissões aplicáveis.
